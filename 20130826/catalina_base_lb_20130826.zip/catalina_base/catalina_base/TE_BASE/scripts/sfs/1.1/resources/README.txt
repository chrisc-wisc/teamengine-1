
Place classpath resources here.
Also list any supporting libraries required by this test suite.
