
The WCS 1.0.0 test suite requires these supporting libraries. Put them in the 
application lib directory (teamengine/WEB-INF/lib/).

- cite1-utils-1.0.jar
  <https://svn.opengeospatial.org/ogc-projects/cite/maven/org/opengis/cite/cite1-utils/1.0/cite1-utils-1.0.jar>

- jaxen-1.0-FCS.jar
  <http://search.maven.org/remotecontent?filepath=jaxen/jaxen/1.0-FCS/jaxen-1.0-FCS.jar>

- saxpath-1.0-FCS.jar
  <http://search.maven.org/remotecontent?filepath=saxpath/saxpath/1.0-FCS/saxpath-1.0-FCS.jar>
