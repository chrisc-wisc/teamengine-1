The sets of XML Schema Documents for GML Versions 2.0 through 3.1.1 
have been edited to reflect the corrigenda to all those OGC documents 
that are based on the change requests: 
OGC 05-068r1 "Store xlinks.xsd file at a fixed location"
OGC 05-081r2 "Change to use relative paths"

Arliss Whiteside, 2005-11-22

