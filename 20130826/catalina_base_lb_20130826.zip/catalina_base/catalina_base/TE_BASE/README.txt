The value of the TE_BASE system property or environment variable specifies the 
location of the main configuration directory that contains several essential 
sub-directories (see structure below). Unpack the contents of the *-base.zip 
archive into the TE_BASE directory.

TE_BASE
  |-- config.xml             # main configuration file (web app)
  |-- resources/             # Contains test suite resources (CLI)
  |-- scripts/               # Contains CTL test suites
  |   |--- ets.ctl           # Stand-alone script
  |   +--- {ets}/            # A test suite package
  |
  |-- work/                  # teamengine work directory
  +-- users/
      +-- {username}/        # user credentials & test runs (web app)


The "resources" sub-directory contains libraries and other resources that are 
required to execute a test suite using a command-line shell; it should be 
structured as indicated below.

resources/
  |
  +-- lib/*.jar
